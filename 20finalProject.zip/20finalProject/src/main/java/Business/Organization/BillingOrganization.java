/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.BillingRole;
import Business.Role.NutritionistRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class BillingOrganization extends Organization{

    public BillingOrganization() {
        super(Organization.Type.Billing.getValue());
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new BillingRole());
        return roles;
    }
     
   
    
    
}
