package Business;

import Business.Employee.Employee;
import Business.Role.SupplierRole;
import Business.Role.SystemAdminRole;
import Business.Role.UserRole;
import Business.UserAccount.UserAccount;

/**
 *
 * @author rrheg
 */
public class ConfigureASystem {
    
    public static EcoSystem configure(){
        
        EcoSystem system = EcoSystem.getInstance();
        
        //Create a network
        //create an enterprise
        //initialize some organizations
        //have some employees 
        //create user account
        
        
        Employee employee = system.getEmployeeDirectory().createEmployee("sysadmin");
        
        UserAccount ua = system.getUserAccountDirectory().createUserAccount("sysadmin", "sysadmin", employee, new SystemAdminRole());
        //UserAccount supp = system.getUserAccountDirectory().createUserAccount("supplier", "123", employee, new SupplierRole());
        
        Employee emp = system.getEmployeeDirectory().createEmployee("supplier");
        
        UserAccount sup = system.getUserAccountDirectory().createUserAccount("supp", "234", emp, new SupplierRole());
        
        Employee ee = system.getEmployeeDirectory().createEmployee("user mith");
        
        UserAccount ua2 = system.getUserAccountDirectory().createUserAccount("mith", "1234", ee, new UserRole());
        
        return system;
    }
    
}
