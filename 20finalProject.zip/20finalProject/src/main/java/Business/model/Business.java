/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.model;

import Business.Organization.SupplierDirectory;

/**
 *
 * @author ezhil
 */
public class Business {
    
    MasterOrderList masterOrderList;
    SupplierDirectory supplierDirectory;
    BillingDirectory billingDirectory;

    
    public Business(){
        
        masterOrderList=new MasterOrderList();
        supplierDirectory = new SupplierDirectory();
        billingDirectory = new BillingDirectory();
    }

    public MasterOrderList getMasterOrderList() {
        return masterOrderList;
    }

    public void setMasterOrderList(MasterOrderList masterOrderList) {
        this.masterOrderList = masterOrderList;
    }

    public SupplierDirectory getSupplierDirectory() {
        return supplierDirectory;
    }

    public void setSupplierDirectory(SupplierDirectory supplierDirectory) {
        this.supplierDirectory = supplierDirectory;
    }
        public BillingDirectory getBillingDirectory() {
    return billingDirectory;
    }
        public void setBillingDirectory(BillingDirectory billingDirectory) {
        this.billingDirectory = billingDirectory;
    }
        
}
    

