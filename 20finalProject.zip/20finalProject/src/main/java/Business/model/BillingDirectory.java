/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ezhil
 */
public class BillingDirectory {
    private List<Billing> billingList;
    

    public BillingDirectory() {
        billingList = new ArrayList<>();
    }

    public List<Billing> getBillingList() {
        return billingList;
    }

    public void addBilling(Billing billing) {
        billingList.add(billing);
    }

    public Billing findBillingByOrderId(String orderId) {
        for (Billing b : billingList) {
            if (b.getOrderId().equals(orderId)) {
                return b;
            }
        }
        return null;
    }
    
}

