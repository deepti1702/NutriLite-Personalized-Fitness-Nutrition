/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.model;

import Business.Organization.Product;
import java.util.ArrayList;
import java.util.UUID;

/**
 *
 * @author ezhil
 */
public class Order {
    
     private String orderId; // Unique order ID
    private ArrayList<OrderItem> orderItemList;

    public Order() {
        this.orderId = UUID.randomUUID().toString(); // Generate a unique order ID
        this.orderItemList = new ArrayList<OrderItem>();
    }

    // Getter for order ID
    public String getOrderId() {
        return orderId;
    }

    public ArrayList<OrderItem> getOrderItemList() {
        return orderItemList;
    }

    public void setOrderItemList(ArrayList<OrderItem> orderItemList) {
        this.orderItemList = orderItemList;
    }

    public void addNewOrderItem(Product product, double price, int quantity) {
        OrderItem orderItem = new OrderItem(product, price, quantity);
        orderItemList.add(orderItem);
    }

    public void deleteItem(OrderItem item) {
        this.orderItemList.remove(item);
    }

    public OrderItem findProduct(Product product) {
        for (OrderItem oi : this.orderItemList) {
            if (oi.getProduct().equals(product)) {
                return oi;
            }
        }
        return null;
    }

    // Calculate the total cost of the order
    public double calculateTotalAmount() {
        double total = 0.0;
        for (OrderItem item : orderItemList) {
            total += item.getSalesPrice() * item.getQuantity();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId;
    }
}